import React from 'react';
import { TemplatePage } from './TemplatePage';

export function DashboardPage() {
  return (
    <TemplatePage 
      title="Dashboard" 
      subtitle="Real-time telemetry and harvest analytics for your local production facility." 
    />
  );
}
