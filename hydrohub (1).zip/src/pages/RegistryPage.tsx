import React from 'react';
import { TemplatePage } from './TemplatePage';

export function RegistryPage() {
  return (
    <TemplatePage 
      title="Registry" 
      subtitle="The comprehensive network index of all verified laboratory nodes across the enterprise hydroponics grid." 
    />
  );
}
